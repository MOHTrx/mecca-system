const fetch = require("node-fetch");

const TG_TOKEN = "8001069272:AAG7V7VWOpaujoXDBQBdk3Wi6h9-t0gMlOA";
const TG_CHATID = "965684819";

exports.handler = async (event) => {

  if(event.httpMethod !== "POST"){
    return {statusCode:405, body:"Method not allowed"};
  }

  const data = JSON.parse(event.body);

  const message = `
🏭 طلب جديد - شركة مكة

👤 ${data.name}
📞 ${data.phone}
🎂 ${data.age}
📍 ${data.gov}
🎓 ${data.edu}
💼 ${data.exp}
`;

  await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({
      chat_id:TG_CHATID,
      text:message
    })
  });

  return {
    statusCode:200,
    body:JSON.stringify({ok:true})
  };
};